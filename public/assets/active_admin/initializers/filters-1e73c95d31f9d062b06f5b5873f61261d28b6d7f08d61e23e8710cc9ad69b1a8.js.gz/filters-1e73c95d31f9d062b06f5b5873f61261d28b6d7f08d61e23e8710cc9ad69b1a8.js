(function() {
  $(document).on('ready page:load turbolinks:load', function() {
    $('.clear_filters_btn').click(function(e) {
      var param, params, regex;
      params = window.location.search.slice(1).split('&');
      regex = /^(q\[|q%5B|q%5b|page|commit)/;
      if (typeof Turbolinks !== 'undefined') {
        Turbolinks.visit(window.location.href.split('?')[0] + '?' + ((function() {
          var _i, _len, _results;
          _results = [];
          for (_i = 0, _len = params.length; _i < _len; _i++) {
            param = params[_i];
            if (!param.match(regex)) {
              _results.push(param);
            }
          }
          return _results;
        })()).join('&'));
        return e.preventDefault();
      } else {
        return window.location.search = ((function() {
          var _i, _len, _results;
          _results = [];
          for (_i = 0, _len = params.length; _i < _len; _i++) {
            param = params[_i];
            if (!param.match(regex)) {
              _results.push(param);
            }
          }
          return _results;
        })()).join('&');
      }
    });
    $('.filter_form').submit(function(e) {
      $(this).find(':input').filter(function() {
        return this.value === '';
      }).prop('disabled', true);
      if (typeof Turbolinks !== 'undefined') {
        Turbolinks.visit(window.location.href.split('?')[0] + '?' + $(this).serialize());
        return e.preventDefault();
      }
    });
    return $('.filter_form_field.select_and_search select').change(function() {
      return $(this).siblings('input').prop({
        name: "q[" + this.value + "]"
      });
    });
  });

}).call(this);
